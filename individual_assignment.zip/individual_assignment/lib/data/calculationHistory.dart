import 'package:flutter/cupertino.dart';
List<CalculationData> listOfData = [];

class CalculationData extends ChangeNotifier {

  int numOfMonth = 0;
  double dividendRate = 0, investedFundAmount = 0;
  double monthlyDividend = 0 , totalDividend = 0;

  calculationData(double investedFund , double divRate , int  numMonth){
    investedFundAmount = investedFund;
    dividendRate = divRate;
    numOfMonth = numMonth;
    monthlyDividend = 0;
    totalDividend =0;
  }


  calculateDividend(CalculationData data){
    monthlyDividend = (data.dividendRate / 100 / 12) * data.investedFundAmount;
    totalDividend = data.monthlyDividend * data.numOfMonth;
  }


}