import 'package:flutter/cupertino.dart';

class AboutClass {

  final applicationName = "Dividend Calculator";
  final applicationLogo = Image.asset(
      'lib/assets/calculatorLogo.png',
    semanticLabel: "Application Logo",
    width: 100,
    height: 100,
  );
  final applicationVersion = "1.0.0";
  final authorName = "Nazreen Eidri Muda bin Muda Alang";
  final studentId = "2024988385";
  final phoneNumber = "(+60)-1129387698";
  final email = "Meidri03@gmail.com";
  final waLink = "https://wa.link/l9cqbq";
  final igLink = "https://ig.me/m/nazreeneidrimuda";
  final gmailLink = "mailto:2024988385@student.uitm.edu.my";
  final githubLink = "https://github.com/Nazreeneidri25";
}