import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:individual_assignment/page/about.dart';
import 'package:individual_assignment/page/calculator.dart';
import 'package:individual_assignment/page/home.dart';
import 'package:individual_assignment/widgets/parentwidget.dart';
enum AppRoute{
  about,
  calculator,
  home,
}
final GoRouter routing = GoRouter(
    routes: [
      GoRoute(
          path: '/',
          name: 'home',
          builder: (context , state) => ParentWidget(child: const HomePage()),
          routes: [
            GoRoute(
              path: 'about',
              name: 'about',
              builder: (context , state) => ParentWidget(child: const AboutPage())
            ),
            GoRoute(
                path: 'calculator',
                name: 'calculator',
                builder: (context , state) => ParentWidget(child: const CalculatorPage())
            ),
          ]
      )
    ]);