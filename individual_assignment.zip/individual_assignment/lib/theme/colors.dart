import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../widgets/parentwidget.dart';

class CustomThemes {
  Color primaryColor = useLightTheme ? Color(0xFF111D4A) : Color(0xFF0D1821);
  Color secondaryColor = useLightTheme ? Color(0xFFE1E2EF) : Color(0xFF2F2F2F);
  Color tertiaryColor = useLightTheme ? Color(0xFF0D1821) : Color(0xFFF6F8FF);
  Color textPrimaryColor =  useLightTheme ? Color(0xFF14213D) : Color(0xFFF7F7F9);
  Color textSecondaryColor = useLightTheme ?  Color(0xFFF7F7F9) : Color(0xFF14213D);
  Color textTertiaryColor = Color(0xFFF7F7F9);
  Color resetButton = useLightTheme ? Color(0xFF96031A) : Color(0xFFC41E3D);
  Color elevatedButton = useLightTheme ? Color(0xFF2C3D55) : Color(0xFFF3F8F2);
}



