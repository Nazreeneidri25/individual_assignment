import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:individual_assignment/data/calculationHistory.dart';
import 'package:individual_assignment/data/dataAbout.dart';
import 'package:individual_assignment/theme/colors.dart';


class HomePage extends StatefulWidget {
  const HomePage({Key? key }) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: CustomThemes().secondaryColor,
        body: SafeArea(
            child:
            Column(
                children: [
                  Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: CustomThemes().primaryColor,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black12,
                            blurRadius: 16,
                            offset: Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          _profileContainer(AboutClass().authorName.split("bin").first , "lib/assets/user.png"),
                          _progressBar(79),
                        ],
                      )),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Recents",
                          style: Theme.of(context).textTheme.titleMedium ,
                        ),
                        Row(children: [
                          IconButton(
                              onPressed: () =>
                                  setState(() {
                                    listOfData;
                                  }),
                              icon: Icon(
                                Icons.refresh_rounded,
                                color: CustomThemes().textPrimaryColor,
                              )),
                          Material(
                            color: CustomThemes().primaryColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child:
                            InkWell(
                              borderRadius: BorderRadius.circular(16),
                              onTap: () => context.goNamed("calculator"),
                              child: Padding(
                                padding: const EdgeInsets.all(10),
                                child: Icon(
                                  Icons.calculate_rounded,
                                  color: Colors.white,
                                  size: 28,
                                ),
                              ),
                            ),
                          )
                        ])
                      ],
                    ),
                  ),
                  listOfData.isEmpty ? Text("No recents data" , style:  TextStyle(color:  CustomThemes().textPrimaryColor))
                      : Expanded(child: _listViewHistory())
                ])
        ));
  }

  Widget _profileContainer(String username, String asset) {
    return Row(
      children: [
        CircleAvatar(
          radius: 36,
          backgroundImage: AssetImage(asset),
        ),
        const SizedBox(width: 20),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Welcome back,",
                style: TextStyle(
                  color: Colors.grey,
                  fontWeight: FontWeight.w700
                )
              ),
              Text(
                username,
                style: Theme.of(context).textTheme.titleSmall
              ),
            ],
          ),
        ),
        IconButton(
          icon: Icon(Icons.edit, color: CustomThemes().textTertiaryColor),
          onPressed: () {},
        ),
      ],
    );
  }

  Widget _progressBar(double val) {
    int curr = val.toInt();

    return Padding(
        padding: EdgeInsets.all(24),
        child: Container(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Beginner Finance" , style: Theme.of(context).textTheme.labelSmall),
                  Text("Saving Goals $curr / 100" , style: Theme.of(context).textTheme.labelSmall),
                ],
              ),
              SizedBox(height: 16),
              LinearProgressIndicator(
                value: val / 100,
                borderRadius: BorderRadius.circular(24),
                color: CustomThemes().textTertiaryColor,
                minHeight: 20,
                backgroundColor: Theme.of(context).colorScheme.primary
              )
            ],
          ),
        )
    );
  }

  Widget _listViewHistory() {
    return Scrollbar(
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        itemCount: listOfData.length,
        separatorBuilder: (context, index) => const SizedBox(height: 16),
        itemBuilder: (context, index) {
          final data = listOfData[index];
          return Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            color: Colors.white,
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: CustomThemes().secondaryColor.withOpacity(0.2),
                child: Icon(Icons.monetization_on_rounded, color: CustomThemes().primaryColor),
              ),
              title: Text(
                "Total Dividend : RM ${data.totalDividend.toStringAsFixed(2)}",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: CustomThemes().primaryColor,
                ),
              ),
              subtitle: Text(
                "Monthly Dividend : RM ${data.monthlyDividend.toStringAsFixed(2)}",
                style: TextStyle(
                  color: Colors.grey[700],
                ),
              ),
              trailing: Icon(Icons.arrow_forward_ios_rounded, color: Colors.grey[400], size: 20),
            ),
          );
        },
      ),
    );
  }
}