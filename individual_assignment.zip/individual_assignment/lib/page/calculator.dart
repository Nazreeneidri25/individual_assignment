import 'package:flutter/material.dart';
import 'package:individual_assignment/data/calculationHistory.dart';
import 'package:individual_assignment/theme/colors.dart';

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({Key? key}) : super(key: key);

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _rateController = TextEditingController();
  int? _selectedMonth;
  double? _monthlyDividend;
  double? _totalDividend;


  void _calculateDividend() {
    if (_formKey.currentState!.validate()) {
      final amount = double.parse(_amountController.text);
      final rate = double.parse(_rateController.text);
      final months = _selectedMonth;


      CalculationData data = CalculationData();
      data.calculationData(amount , rate , months!);
      data.calculateDividend(data);

      setState(() {
        listOfData.add(data);
        _monthlyDividend = data.monthlyDividend;
        _totalDividend = data.totalDividend;
      });
    }
  }

  void _resetForm(){
    setState(() {
      _amountController.clear();
      _rateController.clear();
      _monthlyDividend = null;
      _selectedMonth = null;
      _totalDividend = null;
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _rateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomThemes().secondaryColor,
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                    labelText: 'Invested Fund Amount',
                    prefixIcon: Icon(Icons.attach_money),
                    filled: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                    )
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) return 'Enter amount';
                  final v = double.tryParse(value);
                  if (v == null || v <= 0) return 'Enter valid amount';
                  return null;
                },
                style: Theme.of(context).textTheme.labelLarge,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _rateController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                    labelText: 'Annual Dividend Rate (%)',
                    prefixIcon: Icon(Icons.percent),
                    filled: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                    )
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) return 'Enter rate';
                  final v = double.tryParse(value);
                  if (v == null || v <= 0) return 'Enter valid rate';
                  return null;
                },
                style: Theme.of(context).textTheme.labelLarge,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<int>(
                value: _selectedMonth,
                decoration: const InputDecoration(
                  labelText: 'Number of Months Invested (max 12)',
                  prefixIcon: Icon(Icons.calendar_today),
                  filled: true,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                ),
                items: List.generate(
                  12,
                      (index) => DropdownMenuItem(
                    value: index + 1,
                    child: Text('${index + 1}'),
                  ),
                ),
                onChanged: (value) {
                  setState(() {
                    _selectedMonth = value;
                  });
                },
                validator: (value) =>
                value == null ? 'Select number of months' : null,
                style: Theme.of(context).textTheme.labelLarge,
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  ElevatedButton(
                    onPressed: _calculateDividend,
                    child: const Text('Calculate'),
                  ),
                  ElevatedButton(
                    onPressed: _resetForm,
                    child: const Text('Reset'),
                    style: ButtonStyle(
                      backgroundColor: WidgetStatePropertyAll(CustomThemes().resetButton)

                    ),
                  ),
                ],
              ),
              const SizedBox(height: 32),
              if (_monthlyDividend != null && _totalDividend != null)
                Container(
                  margin: const EdgeInsets.only(top: 16),
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [CustomThemes().secondaryColor, CustomThemes().primaryColor],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: CustomThemes().primaryColor,
                        blurRadius: 12,
                        offset: Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Icon(Icons.calculate_rounded, color: CustomThemes().elevatedButton, size: 48),
                      const SizedBox(height: 12),
                      Text(
                        'Results',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: CustomThemes().textTertiaryColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 28,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              Text('Monthly Dividend', style: Theme.of(context).textTheme.titleSmall),
                              const SizedBox(height: 4),
                              Text(
                                'RM ${_monthlyDividend!.toStringAsFixed(2)}',
                                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  color: CustomThemes().textTertiaryColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 24,
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: [
                              Text('Total Dividend', style: Theme.of(context).textTheme.titleSmall),
                              const SizedBox(height: 4),
                              Text(
                                'RM ${_totalDividend!.toStringAsFixed(2)}',
                                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  color: CustomThemes().textTertiaryColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 24,
                                  decoration: TextDecoration.underline
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}