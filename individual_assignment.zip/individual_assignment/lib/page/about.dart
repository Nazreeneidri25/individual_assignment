import 'package:flutter/material.dart';
import 'package:individual_assignment/data/dataAbout.dart';
import 'package:individual_assignment/theme/colors.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher_string.dart';

class AboutPage extends StatefulWidget {
  const AboutPage({super.key});

  @override
  _AboutPageState createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  final aboutInformation = AboutClass();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomThemes().secondaryColor,
      body: SafeArea(
        child: Column(
            children: [
              const SizedBox(height: 32),
              Center(child: aboutInformation.applicationLogo),
              const SizedBox(height: 16),
              Text(
                aboutInformation.applicationName,
                style: Theme.of(context).textTheme.titleLarge,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                'Version ${aboutInformation.applicationVersion}',
                style: Theme.of(context).textTheme.labelSmall!.copyWith(
                  color: Colors.grey
                ),
              ),
              const SizedBox(height: 32),
              Expanded(
                  child : Container(
                      margin: const EdgeInsets.all(0),
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: CustomThemes().primaryColor,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(36),
                            topRight: Radius.circular(36)
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black12,
                            blurRadius: 12,
                            offset: Offset(0, 6),
                          ),
                        ],
                      ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _socialIcon('lib/assets/whatsapp.png' , AboutClass().waLink),
                              _socialIcon('lib/assets/instagram.png' , AboutClass().igLink),
                              _socialIcon('lib/assets/gmail.png' , AboutClass().gmailLink),
                              _socialIcon('lib/assets/github.png', AboutClass().githubLink),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),
                        Divider(
                          thickness: 2,
                          color: Theme.of(context).colorScheme.onPrimary,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Contact Information",
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: CustomThemes().textTertiaryColor
                          ),
                        ),
                        const SizedBox(height: 16),
                        _infoRow("Author Name:", aboutInformation.authorName, context),
                        _infoRow("Student ID:", aboutInformation.studentId, context),
                        _infoRow("Phone Number:", aboutInformation.phoneNumber, context),
                        _infoRow("Email:", aboutInformation.email, context),
                        const SizedBox(height: 60),
                        Row(
                          children: [
                            FloatingActionButton(
                              onPressed: () => launchUrlString(AboutClass().waLink , mode: LaunchMode.externalApplication),
                              child: Icon(Icons.messenger_outline_rounded , color: CustomThemes().elevatedButton),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  minimumSize: const Size(double.infinity, 60),
                                ),
                                onPressed: () => launchUrlString(AboutClass().gmailLink , mode: LaunchMode.externalApplication),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.phone_callback_rounded , color:  CustomThemes().textSecondaryColor),
                                    const SizedBox(width: 16),
                                    Text("Contact Us" , style:  TextStyle(
                                      color: CustomThemes().textSecondaryColor,
                                    ),),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
              )),
            ],
          ),
        ),
    );
  }
  Widget _socialIcon(String asset , link) {
    
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => launchUrlString(link , mode:  LaunchMode.externalApplication),
        child: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Image.asset(asset, width: 36, height: 36),
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(
              label,
              style: Theme.of(context).textTheme.labelSmall
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              value,
              style: Theme.of(context).textTheme.labelSmall
            ),
          ),
        ],
      ),
    );
  }
}