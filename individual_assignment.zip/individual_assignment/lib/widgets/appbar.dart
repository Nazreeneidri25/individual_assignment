import 'package:flutter/material.dart';
import 'package:individual_assignment/data/dataAbout.dart';
import 'package:individual_assignment/theme/colors.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  const CustomAppBar({super.key,});

  @override
  Widget build(BuildContext context) {
    final aboutInformation = AboutClass();

    return AppBar(
      title: Text(aboutInformation.applicationName),
      primary: true,
      leading: IconButton(
        onPressed: () => Scaffold.of(context).openDrawer(),
        icon: Icon(Icons.menu_rounded, weight: 900),
      ),
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}