import 'package:flutter/material.dart';
import 'package:individual_assignment/theme/colors.dart';
import 'package:individual_assignment/widgets/appbar.dart';
import 'package:individual_assignment/widgets/customContainer.dart';
import 'package:individual_assignment/widgets/sidebar.dart';
import 'package:google_fonts/google_fonts.dart';

bool useLightTheme = true;

class ParentWidget extends StatefulWidget {
  final Widget child;
  const ParentWidget({super.key, required this.child});

  @override
  State<ParentWidget> createState() => _ParentWidgetState();
}

class _ParentWidgetState extends State<ParentWidget> {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: useLightTheme ? CustomTheme(useLightTheme) : CustomTheme(useLightTheme),
        home: Scaffold(
          appBar: CustomAppBar(),
          drawer: SideBar(
              useLightTheme: useLightTheme,
              onThemeChanged: (val) => setState(() => useLightTheme = val)),
          body: CustomContainer(child: widget.child)
        )
    );
  }
}

ThemeData CustomTheme(bool themes) {
  final ThemeData theme = themes
      ? ThemeData.light(useMaterial3: true)
      : ThemeData.dark(useMaterial3: true);

  return theme.copyWith(
    textTheme: CustomTextTheme(
      GoogleFonts.poppinsTextTheme(),
      CustomThemes().textPrimaryColor,
    ),
    iconTheme: IconThemeData(
        color: CustomThemes().primaryColor,
        size: 32
    ),
    listTileTheme: ListTileThemeData(
      textColor: CustomThemes().tertiaryColor,
      titleTextStyle: TextStyle(
          fontSize: 20
      ),
      iconColor: CustomThemes().tertiaryColor,
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: CustomThemes().textSecondaryColor
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ButtonStyle(
        backgroundColor: WidgetStatePropertyAll(CustomThemes().elevatedButton),
        foregroundColor: WidgetStatePropertyAll(CustomThemes().textSecondaryColor),
      )
    ),
    drawerTheme: DrawerThemeData(
     backgroundColor: CustomThemes().secondaryColor
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: CustomThemes().secondaryColor,
      foregroundColor: CustomThemes().textPrimaryColor,
      titleTextStyle: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 25,
        color: CustomThemes().textPrimaryColor
      )
    )
  );
}


TextTheme CustomTextTheme(TextTheme theme, Color colors) {
  return theme.copyWith(
    titleLarge: TextStyle(
      color: CustomThemes().textPrimaryColor,
      fontWeight: FontWeight.w500
    ),
    titleMedium: theme.titleMedium!.copyWith(
      fontSize: 30,
      color : CustomThemes().textPrimaryColor,
      fontWeight: FontWeight.bold
    ),
    titleSmall: theme.titleSmall!.copyWith(
      fontSize: 20,
      color: CustomThemes().textTertiaryColor,
      fontWeight: FontWeight.bold
    ),
    labelSmall: theme.labelSmall!.copyWith(
      fontSize: 15,
        color: CustomThemes().textTertiaryColor,
    ),
    labelLarge: theme.labelLarge!.copyWith(
      color: CustomThemes().textPrimaryColor,
      fontWeight: FontWeight.w900,
    ),
  );
}