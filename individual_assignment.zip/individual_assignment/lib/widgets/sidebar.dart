import 'dart:io';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:individual_assignment/data/dataAbout.dart';
import 'package:individual_assignment/routing/routing.dart';
import 'package:individual_assignment/theme/colors.dart';
import 'package:individual_assignment/widgets/parentwidget.dart';


class SideBar extends StatefulWidget {

  final bool useLightTheme;
  final ValueChanged<bool> onThemeChanged;

  const SideBar({
    Key? key,
    required this.useLightTheme,
    required this.onThemeChanged,
  }) : super(key: key);

  @override
  State<SideBar> createState() => _SideBarState();
}

class _SideBarState extends State<SideBar> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          UserAccountsDrawerHeader(
            accountName: Text(AboutClass().authorName.split("bin").first),
            accountEmail: Text(AboutClass().email),
            currentAccountPicture: CircleAvatar(
              backgroundImage: AssetImage("lib/assets/user.png"),
            ),
            decoration: BoxDecoration(
              color: CustomThemes().primaryColor,
            ),
          ),
          ListTile(
            leading: Icon(Icons.home_rounded),
            title: Text("Home"),
            onTap: () {
              context.goNamed(AppRoute.home.name);
            },
          ),
          ListTile(
            leading: Icon(Icons.calculate_rounded),
            title: Text("Calculator"),
            onTap: () {
              context.goNamed(AppRoute.calculator.name);
            },
          ),
          ListTile(
            leading: Icon(Icons.info_rounded),
            title: Text("About"),
            onTap: () {
              context.goNamed(AppRoute.about.name);
            },
          ),
          const Spacer(),
          ListTile(
              leading: Icon(Icons.logout_rounded, color: Colors.red),
              title: Text("Logout", style: TextStyle(color: Colors.red)),
              onTap: () {
                exit(0);
              },
              trailing: // Place this where you want the button, e.g., in AppBar actions or Drawer

              IconButton(
                icon: Icon(
                  useLightTheme ? Icons.wb_sunny_rounded : Icons
                      .nightlight_round,
                  color: useLightTheme ? CustomThemes().primaryColor : CustomThemes().tertiaryColor,
                ),
                tooltip: useLightTheme
                    ? 'Switch to dark mode'
                    : 'Switch to light mode',
                onPressed: () => widget.onThemeChanged(!useLightTheme),
              )
          ),
        ],
      ),
    );
  }
}
